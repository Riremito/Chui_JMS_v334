# Character field ID when accessed: 910001002
# ObjectID: 1000000
# ParentID: 200010
# Object Position X: 330
# Object Position Y: 507
