# 140090300
sm.dropItem(4032310, sm.getPosition(objectID).getX(), sm.getPosition(objectID).getY())
sm.removeReactor()