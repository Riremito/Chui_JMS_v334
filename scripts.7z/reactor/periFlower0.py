# fire flower in perion mountains

sm.dropItem(4033051, sm.getObjectPositionX(), sm.getObjectPositionY())
sm.removeReactor()