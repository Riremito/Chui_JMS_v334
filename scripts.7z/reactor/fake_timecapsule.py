reactor.incHitCount()
reactor.increaseState()
if reactor.getHitCount() >= 4:
    sm.removeReactor()
