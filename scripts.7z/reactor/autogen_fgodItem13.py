# Character field ID when accessed: 920011100
# ParentID: 2002014
# ObjectID: 1000000
# Object Position Y: 357
# Object Position X: -184
