sm.dropItem(2430071, sm.getPosition(objectID).getX(), sm.getPosition(objectID).getY())
sm.removeReactor()