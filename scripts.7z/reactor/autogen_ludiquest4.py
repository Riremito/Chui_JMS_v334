# ParentID: 2202004
# ObjectID: 1000001
# Character field ID when accessed: 922011000
# Object Position X: -139
# Object Position Y: 352
