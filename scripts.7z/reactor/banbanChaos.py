chaosVonBon = 8910000

sm.spawnMob(chaosVonBon, -135, 455, False)
sm.removeReactor()