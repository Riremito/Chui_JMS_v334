# Baby Seal (1512005) | Barbara's House
sm.sendSayOkay("Arf arf!")
