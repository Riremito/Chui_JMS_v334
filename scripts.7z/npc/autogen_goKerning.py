# Character field ID when accessed: 800000000
# ParentID: 9110008
# ObjectID: 1000001
# Object Position X: 204
# Object Position Y: 26
