# Character field ID when accessed: 800000000
# ParentID: 9135016
# ObjectID: 1000017
# Object Position Y: 93
# Object Position X: 3852
