# ObjectID: 1000010
# Character field ID when accessed: 180000105
# ParentID: 1064015
# Object Position X: 961
# Object Position Y: 198
