 # Sunstone Grave (9201071) | MesoGears: Fire Chamber (600020400)
 # Author: Tiger

sm.sendSayOkay("Tempt Fate. Discover the path.")
