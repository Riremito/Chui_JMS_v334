sm.sendSayOkay("I will send you back to your previous location.")
sm.warp(chr.getPreviousFieldID())