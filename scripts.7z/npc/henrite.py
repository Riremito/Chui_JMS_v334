BRIGHTON = 2151001

sm.setSpeakerID(2151001)

sm.sendNext("What is it?\r\n\r\n#L0##bI want to talk to you.")
sm.sendNext("Well... I'm not really that good with words, you see... I'm not the best person to hang around with.")