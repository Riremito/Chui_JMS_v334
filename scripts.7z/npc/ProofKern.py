# Nana (9201023) |
sm.sendSayOkay("Hihi, I'm Nana the love fairy!")
