# ObjectID: 1000000
# ParentID: 9900001
# Character field ID when accessed: 180010000
# Object Position Y: -95
# Object Position X: 359
