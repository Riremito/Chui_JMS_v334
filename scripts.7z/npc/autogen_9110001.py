# Character field ID when accessed: 800000000
# ObjectID: 1000002
# ParentID: 9110001
# Object Position Y: 93
# Object Position X: 1415
