# Ali 
# Adobis's Mission I: The Room of Tragedy
# not sure what function this room has but it has no portals

sm.sendNext("Why are you here? You shouldn't be here..")
sm.warp(211000000) # warps to El Nath