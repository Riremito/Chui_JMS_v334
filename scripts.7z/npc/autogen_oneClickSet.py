# ObjectID: 1000003
# Character field ID when accessed: 180010000
# ParentID: 9900002
# Object Position X: -220
# Object Position Y: 87
