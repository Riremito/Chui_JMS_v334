# Kyrin (1090000) | Navigation Room
if sm.getChr().getJob() == 0:
    sm.sendSayOkay("Speak to me if you want to become a Pirate.")
else:
    sm.sendSayOkay("You seem to have made a choice already,\r\nThe wrong choice..")
