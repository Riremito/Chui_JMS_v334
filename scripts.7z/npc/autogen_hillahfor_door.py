# ParentID: 2184007
# ObjectID: 1000000
# Character field ID when accessed: 926200001
# Object Position X: 912
# Object Position Y: -441
