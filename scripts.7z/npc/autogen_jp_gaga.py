# ObjectID: 1000010
# Character field ID when accessed: 800000000
# ParentID: 9000021
# Object Position X: 580
# Object Position Y: -37
