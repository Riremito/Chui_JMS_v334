# Character field ID when accessed: 800000000
# ParentID: 9110118
# ObjectID: 1000008
# Object Position X: 1301
# Object Position Y: 88
