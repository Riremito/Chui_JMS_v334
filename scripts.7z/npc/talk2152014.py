FATTIE = 2159014

sm.setSpeakerID(FATTIE)
sm.sendSayOkay("I'm so hot, I'm probably blinding you. I also like balloons. And now, I won't share my balloons with you, so don't even ask.")