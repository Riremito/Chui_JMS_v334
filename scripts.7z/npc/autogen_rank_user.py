# ParentID: 9901000
# ObjectID: 1000001
# Character field ID when accessed: 102000003
# Object Position X: -278
# Object Position Y: 189
