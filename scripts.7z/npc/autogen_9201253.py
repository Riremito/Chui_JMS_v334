# Character field ID when accessed: 910000000
# ParentID: 9201253
# ObjectID: 1000004
# Object Position Y: -332
# Object Position X: -714
