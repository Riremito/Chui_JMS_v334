# Character field ID when accessed: 102000000
# ParentID: 9010009
# ObjectID: 1000019
# Object Position X: 755
# Object Position Y: 1656
