# Baby Malamute (1512002) | Barbara's House
sm.sendSayOkay("Grrr-ruff!")