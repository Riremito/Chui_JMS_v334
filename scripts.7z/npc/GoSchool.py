# Schrodinger (9330189) | Perion
response = sm.sendAskYesNo("Do you wish to visit the #b#m"+ str(744000000) +"##k?")

if response:
    sm.warp(744000000, 0)
