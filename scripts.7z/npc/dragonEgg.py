# dragon Egg  (1013002) |
#todo effects
sm.warp(900020110, 0)
sm.dispose()
