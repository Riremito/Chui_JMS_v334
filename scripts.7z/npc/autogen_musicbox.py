# ObjectID: 1000000
# ParentID: 1033110
# Character field ID when accessed: 101050000
# Object Position Y: -5
# Object Position X: 1089
