# Character field ID when accessed: 800000000
# ObjectID: 1000011
# ParentID: 9110002
# Object Position Y: -95
# Object Position X: 1356
