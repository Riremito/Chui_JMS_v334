from net.swordie.ms.scripts import ScriptType

sm.showHP()
# field scripts should be stopped by warpInstanceOut()