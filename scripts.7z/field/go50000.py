# Inside Dangerous Forest
sm.showEffect("Map/Effect.img/maplemap/enter/50000")