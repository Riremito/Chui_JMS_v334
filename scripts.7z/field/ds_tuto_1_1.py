ARKARIUM = 2159308
sm.removeEscapeButton()

sm.setPlayerAsSpeaker()
sm.sendNext("(Damian... Mother... Please be safe...)")

sm.setSpeakerID(ARKARIUM)
sm.sendSay("You're not even listening. Feh. Say...didn't you once mention that your #rfamily#k lives in the South Region? Heh...")

sm.curNodeEventEnd(True)
sm.warpInstanceIn(924020010, 0)