# Dialog Constants
MASTEMA = 2159307
sm.removeEscapeButton()
sm.setSpeakerID(MASTEMA)

sm.sendNext("Commander! Where were you? I thought maybe #p2159309# had actually made a move against you...")
sm.sendSay("Things are strange around here these days. #p2159309# has it out for you, since you were the one who managed to catch the Goddess of the Temple of Time. He only managed to blind her, but he still thinks he deserves all the credit... Fool.")
sm.forcedInput(2)
sm.curNodeEventEnd(True)