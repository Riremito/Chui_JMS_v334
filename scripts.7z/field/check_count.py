# Ravana's Golden Altar (252030100)
if sm.hasQuest(3863):
    sm.waitForMobDeath(8800200)
    sm.completeQuest(3863) 