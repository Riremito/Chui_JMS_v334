# Leafre Treasure Vault (915010201)

sm.lockInGameUI(True)
sm.forcedInput(2)
sm.sendDelay(1000)
sm.forcedInput(0)

sm.removeEscapeButton()
sm.flipDialoguePlayerAsSpeaker()
sm.sendNext("Aria's portrait... I was wondering if I'd run into you.")
sm.lockInGameUI(False)