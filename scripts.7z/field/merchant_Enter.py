# [Grand Athenaeum] Ariant : Escort Hatsar's Servant
WEALTHY_MERCHANT = 8230000

sm.spawnMob(WEALTHY_MERCHANT, -1669, 245, False)