# Glacier Cutter Base | 141050000


if sm.hasQuest(32187):
    sm.createQuestWithQRValue(32193, "1")
