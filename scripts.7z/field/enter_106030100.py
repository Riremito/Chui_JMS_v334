# On enter mushroom castle theme dungeon
sm.showEffect("Map/Effect.img/temaD/enter/mushCatle")
