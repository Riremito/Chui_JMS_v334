# Entrance to Adventurer Training Center (1010000)
sm.showEffect("Map/Effect.img/maplemap/enter/1010000")
sm.dispose()
