# Horntail | Horntail's cave (easy)


sm.systemMessage("Destroy the crystal to spawn the horntail...")