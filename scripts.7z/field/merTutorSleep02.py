# Fairy Forest : King's Seat

cursedSlumber = 24005

if sm.hasQuest(cursedSlumber):
    sm.completeQuest(cursedSlumber)
    sm.jobAdvance(2300)  # Mercedes 1st Job
    sm.removeSkill(20021166)  # Remove the Beginner Stunning Strike Skill
    sm.removeSkill(20021181)  # Remove the Beginner Flash Jump Skill