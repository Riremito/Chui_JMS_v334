sm.lockInGameUI(True)
sm.reservedEffect("Effect/Direction4.img/cannonshooter/Scene00")
sm.reservedEffect("Effect/Direction4.img/cannonshooter/out00")
