# Mastema | Demon 3rd job
sm.spawnMob(9001038, 987, -14, False)
sm.waitForMobDeath(9001038)
sm.warpInstanceOut(931050110)

