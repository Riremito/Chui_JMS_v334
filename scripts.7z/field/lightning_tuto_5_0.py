sm.lockInGameUI(True)
sm.reservedEffect("Effect/Direction8.img/lightningTutorial/Scene1")
sm.sendDelay(9000)

sm.warp(927020070, 0)