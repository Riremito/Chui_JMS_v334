# Canal Battleground 5 (865020051) | Used for the Commerci Quest line
i = 0
while i < 10:
    sm.spawnMob(9390829, 500, 352, False) # Cutthroat Delfino
    sm.spawnMob(9390830, 250, 352, False) # Sureshot Delfino
    sm.spawnMob(9390831, 750, 352, False) # Voodoo Delfino
    sm.spawnMob(9390832, 1000, 352, False) # Ripclaw Delfino
    i += 1
sm.spawnMob(9390812, 850, 352, False) # Riverson
sm.dispose()
