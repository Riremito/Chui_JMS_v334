sm.lockInGameUI(True)
sm.blindEffect(False)
sm.blindEffect(True)
sm.chatScript("The Secret Garden Depths")
sm.chatScript("On a rainy day...")
sm.forcedInput(0)
sm.sendDelay(3000)

sm.forcedInput(2)