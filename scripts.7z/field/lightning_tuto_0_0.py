# Hidden Street : Before the Final Battle (927020080)
sm.lockInGameUI(True)
sm.forcedInput(0)
sm.reservedEffect("Effect/Direction8.img/lightningTutorial/Scene0")
sm.sendDelay(3300)

sm.lockInGameUI(False)
sm.warp(927020000, 0)
