# Hidden street : The Nightmare
sm.spawnMob(9300742, 238, 109, False)
sm.waitForMobDeath(9300742)
sm.sendDelay(500)
sm.warpInstanceOut(130000000, 0)




