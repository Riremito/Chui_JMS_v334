# Pink Zakum : Pink Zakum Entrance
# Called when user enters pink zakum auto event lobby

sm.sendAutoEventClock()