sm.reservedEffect("Effect/Direction7.img/mikhail/1st_Job")
sm.invokeAfterDelay(4000, "warpInstanceOut", 130000000, 0)# hacky