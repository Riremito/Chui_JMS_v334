# Map for Mercedes Scene

sm.showScene("Effect.wz/Direction5.img", "mersedesTutorial", "Scene1")
sm.invokeAfterDelay(3500, "lockInGameUI", False)
