# adventurer training center 1
sm.showEffect("Map/Effect.img/maplemap/enter/1010100")