# Lion King's castle Audience room (211070100)  | enter field for von leon
# spawns von leon npc, has a talk, then morphs into boss (in VanLeon_Summon script)

VON_LEON_NPC = 2161000
SPAWNX = -10
SPAWNY = -181

sm.spawnNpc(VON_LEON_NPC, SPAWNX, SPAWNY)