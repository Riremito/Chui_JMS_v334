sm.lockInGameUI(False)
sm.progressMessageFont(3, 20, 20, 0, "You can start the quest by clicking the NPC with the lightbulb over their head.")
sm.blindEffect(False)