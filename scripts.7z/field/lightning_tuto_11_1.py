LANIA = 1032201
PENNY = 1032202

sm.forcedInput(0)
sm.lockInGameUI(False)
sm.removeNpc(LANIA)
sm.removeNpc(PENNY)
sm.warp(910141020)