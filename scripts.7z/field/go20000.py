# Snail Park
sm.showEffect("Map/Effect.img/maplemap/enter/20000")