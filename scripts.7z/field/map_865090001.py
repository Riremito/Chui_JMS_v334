# Commerci Republic : Berry (Hidden Street) | 9390242
if sm.hasQuest(17613): # [Commerci Republic] The Minister's Son
    i = 0
    while i < 12:
        sm.spawnMob(9390847, 996, 132, False)
        i += 1
sm.dispose()
