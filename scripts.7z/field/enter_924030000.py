# Hidden Street : Stone Colossus (924030000)  |  Used to spawn Dark Elizas for the [Stone Colossus] Quest line


for x in range(6):
    sm.spawnMob(9100044, (150*x), 60, False)

