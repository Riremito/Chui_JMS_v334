sm.lockInGameUI(True)
sm.playVideoByScript("Luminous.avi")

sm.warp(910141040)

