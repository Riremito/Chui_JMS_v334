# Field script for entering Ellinel Fairy Academy

MIDSUMMER_NIGHTS_FOREST_ELLINEL_LAKE_SHORE = 101070000 # MAP ID

sm.invokeAfterDelay(5000, "warp", MIDSUMMER_NIGHTS_FOREST_ELLINEL_LAKE_SHORE, 0)

