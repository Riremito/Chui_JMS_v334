# Captain's Quarters (106030800)

blackViking = 3300110

sm.spawnMob(blackViking)