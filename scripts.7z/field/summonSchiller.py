# Hidden Street - 2nd Job Advancement (Resistance)
sm.setInstanceTime(10*60, 310000000)
sm.spawnNpc(2159100, 235, -14)