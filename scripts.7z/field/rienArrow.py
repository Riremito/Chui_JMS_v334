# 140010000
if not "arr=o" in sm.getQRValue(21019):
    sm.avatarOriented("Effect/OnUserEff.img/guideEffect/aranTutorial/tutorialArrow3")
    sm.addQRValue(21019, "arr=o")