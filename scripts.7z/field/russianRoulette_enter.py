# using a map script cuz i cant get the clock to show up immediately after forcing a cc

sm.sendAutoEventClock()