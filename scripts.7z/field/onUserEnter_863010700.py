sm.setSpeakerID(9390124) #Heart Tree Guardian
sm.sendSayOkay("Enter Gollux's heart and pacify it. You must hurry, the window for success is closing.")
