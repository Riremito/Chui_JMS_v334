sm.lockInGameUI(True)
sm.reservedEffect("Effect/Direction8.img/lightningTutorial2/Scene1")
sm.sendDelay(10000)

sm.lockInGameUI(False)
sm.warp(910141010, 0)