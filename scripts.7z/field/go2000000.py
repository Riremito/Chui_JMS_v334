# South Perry (2000000)
sm.showEffect("Map/Effect.img/maplemap/enter/2000000")
sm.dispose()
