if chr is not None:
    sm.chat("(Field) Not coded. ID: " + str(parentID))
