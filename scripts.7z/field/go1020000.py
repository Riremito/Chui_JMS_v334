# Split Road of Destiny (1020000)
sm.showEffect("Map/Effect.img/maplemap/enter/1020000")
sm.dispose()
