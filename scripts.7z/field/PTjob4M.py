# Lush Forest (240010102) | Phantom 4th Job

if sm.hasQuest(25120):
    sm.completeQuest(25120)