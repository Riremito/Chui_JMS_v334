# Hidden Street : Temple of Time Corridor (927020010) | Luminous Intro
sm.lockInGameUI(True)
sm.removeEscapeButton()
sm.curNodeEventEnd(True)
sm.showBalloonMsg("Effect/Direction8.img/effect/tuto/BalloonMsg0/2", 4000)
sm.forcedInput(2)