if chr.getInstance() is not None:
    chr.getInstance().stopEvents()
    chr.getInstance().getFields().clear()