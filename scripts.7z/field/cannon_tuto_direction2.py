sm.lockInGameUI(True)
sm.playSound("cannonshooter/bang", 100)
sm.reservedEffect("Effect/Direction4.img/cannonshooter/Scene01")
sm.reservedEffect("Effect/Direction4.img/cannonshooter/out02")
