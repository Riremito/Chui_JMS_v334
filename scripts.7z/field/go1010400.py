# adventurer training center 4
sm.showEffect("Map/Effect.img/maplemap/enter/1010400")