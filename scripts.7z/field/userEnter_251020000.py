# SnowFro's Lair (251020000)

# Summon SnowFro the Fruitnificent on entry
if not sm.hasMobsInField():
    sm.spawnMob(9100024, -920, -255, False)
