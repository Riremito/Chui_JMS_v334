# Mastema | Demon 2nd job
sm.spawnMob(9001036, 640, -14, False)
sm.waitForMobDeath(9001036)
sm.warpInstanceOut(931050110)

