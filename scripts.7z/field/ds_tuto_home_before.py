sm.lockInGameUI(True)
sm.forcedInput(1)
sm.sendDelay(30)

sm.forcedInput(0)
sm.sendDelay(90)

sm.showFieldEffect("demonSlayer/text11", 0)
sm.sendDelay(4000)

sm.reservedEffect("Effect/Direction6.img/DemonTutorial/Scene2")