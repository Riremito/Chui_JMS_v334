# Golden Temple (252000000)

# Golden Temple Theme Dungeon Effect
sm.showFieldEffect("Map/Effect.img/temaD/enter/goldTemple") 
