PLAY_HOUSE = 9300522
sm.killMobs()
if sm.hasQuest(2606):
    sm.spawnMob(9300522, -500, 152, False)
    sm.spawnMob(9300522, -300, 152, False)
    sm.spawnMob(9300521, -100, 152, False)
    sm.spawnMob(9300522, 100, 152, False)
    sm.spawnMob(9300522, 300, 152, False)