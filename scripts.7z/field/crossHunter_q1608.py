# Hidden Street : Strange Path (931050410)  |  Used for Silent Crusade questline

STARLING = 9073000

sm.spawnNpc(STARLING, -611, 214)

sm.waitForMobDeath(9300471)

#if sm.hasQuest(1608):
#    sm.completeQuest(1608)