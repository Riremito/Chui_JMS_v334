# Overlooked Area (260010601) | Phantom 3rd Job

if sm.hasQuest(25110):
    sm.completeQuest(25110)