# Rien Strait - Glacial Observatory
sm.showFieldEffect("Map/Effect.img/temaD/enter/glacierExplorer") # Riena Strait Theme Dungeon  Effect
