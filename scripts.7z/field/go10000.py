# Maple Hall (10000)
sm.showEffect("Map/Effect.img/maplemap/enter/10000")
sm.dispose()
