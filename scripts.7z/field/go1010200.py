# adventurer training center 2
sm.showEffect("Map/Effect.img/maplemap/enter/1010200")