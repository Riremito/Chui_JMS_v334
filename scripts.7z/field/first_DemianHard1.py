sm.spawnMob(8880110, 1073, 16, False, 25200000000000) # 25.2t
while sm.hasMobsInField():
    sm.waitForMobDeath()
sm.warp(350160240)
