# Lion King's Castle | Desolate Moor (211060000)

sm.showFieldEffect("Map/Effect.img/temaD/enter/lionCastle")