# Curbrock Scene 1

sm.stopEvents()
sm.showFieldEffect("Map/Effect.img/Curbrock0/frame")
sm.showFieldEffect("Map/Effect.img/Curbrock0/002")