sm.lockInGameUI(True)
sm.reservedEffect("Effect/Direction8.img/lightningTutorial/Scene2")
sm.playExclSoundWithDownBGM("Voice.img/DarkMage/5", 100)
sm.sendDelay(7200)

sm.lockInGameUI(False)
sm.warp(910141000, 0)