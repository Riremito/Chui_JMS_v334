# Hidden Street : Destroyed Temple of Time Entrance (927020000) | Used in Luminous' Intro
PHANTOM = 2159353

sm.lockInGameUI(True)
sm.curNodeEventEnd(True)
sm.removeEscapeButton()

sm.flipDialoguePlayerAsSpeaker()
sm.sendNext("The heavens have set the perfect stage for our final confrontation.")
sm.sendDelay(500)

sm.forcedInput(1)
