# Amherst (1000000)
sm.showEffect("Map/Effect.img/maplemap/enter/1000000")
sm.dispose()
