# Limbert's General Store (913070002) used to unlock ui and few progress messages
sm.lockInGameUI(False)  
sm.chatScript("Mr. Limbert's General Store")
sm.chatScript("Month 3, Day 8")
sm.dispose()