# Field Script for Evan Intro | Utah's House: Attic (100030100)
# Author: Tiger

# TODO: there should be a WZ effect here but, can't find it...
# "Carry out the terms of the agreement"
