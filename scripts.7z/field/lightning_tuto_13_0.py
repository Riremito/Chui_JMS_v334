sm.lockInGameUI(True)
sm.reservedEffect("Effect/Direction8.img/lightningTutorial2/Scene4")
sm.sendDelay(10000)

sm.lockInGameUI(False)
sm.warp(910141030, 0)