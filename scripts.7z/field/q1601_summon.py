time = 7 *60

sm.setInstanceTime(time, 103020000, 2)