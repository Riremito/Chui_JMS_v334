# Snail Garden
sm.showEffect("Map/Effect.img/maplemap/enter/30000")