# Inside Small Forest
sm.showEffect("Map/Effect.img/maplemap/enter/40000")